<?php
define("HOTE","webetu.univ-st-etienne.fr");
define("UTILISATEUR","ec05265w");
define("PASSE","4HM2I5P1");
?>
