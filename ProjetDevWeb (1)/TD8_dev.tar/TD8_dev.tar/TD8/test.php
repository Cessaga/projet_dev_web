<?php
include('connex.inc.php');
include('create.php');
$pdo = connexion('ev01484w');
create($pdo);

?>
